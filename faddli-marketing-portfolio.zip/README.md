# Faddli Ramadhan — Marketing Portfolio

Personal portfolio website for Muhamad Faddli Ramadhan.

## GitHub Pages setup
1. Create a repository named `faddliramadhan.github.io`.
2. Upload `index.html`, `style.css`, `script.js`, and your CV PDF.
3. In GitHub: **Settings → Pages → Deploy from a branch → main → / (root)**.
4. Your site will be available at `https://faddliramadhan.github.io/`.

## Before publishing
- Replace the CV filename in `index.html` if your PDF has a different filename.
- Add real project visuals/screenshots later if available.
- Review any metrics before publishing to ensure they match your latest CV.
